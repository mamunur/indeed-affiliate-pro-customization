
<div class="uap-wrapper">
<?php //echo do_shortcode("[uap-affiliate field='CUSTOM_FIELD_Ethereum_Wallet']"); ?>
 <form id="user_payout_form" method="post" action="<?php echo $data['submit_link'];?>">
	 <input type="hidden" value="1" name="payment_status" />
<?php //echo '<pre>'.print_r($data, 1).'</pre>'; ?>

<?php if (!empty($data['affiliate_pay'])) : ?>			
		<table class="wp-list-table widefat fixed tags" style="margin-top:30px;">
						<thead>
							<tr>
								<th><?php _e('Payment Type', 'uap');?></th>
								<th><?php _e('Payment Details', 'uap');?></th>
								<th><?php _e('Rank', 'uap');?></th>
								<th><?php _e('E-mail', 'uap');?></th>
								<th><?php _e('Amount', 'uap');?></th>
							</tr>
						</thead>
						<tfoot>
							<tr>
								<th><?php _e('Payment Type', 'uap');?></th>
								<th><?php _e('Payment Details', 'uap');?></th>
								<th><?php _e('Rank', 'uap');?></th>
								<th><?php _e('E-mail', 'uap');?></th>
								<th><?php _e('Amount', 'uap');?></th>
							</tr>
						</tfoot>
				<tbody class="ui-sortable uap-alternate">
				<tr>
					<td><?php
						if (!empty($data['affiliate_pay']['payment_gateway_data']) && !empty($data['affiliate_pay']['payment_gateway_data']['type'])){
			$temp_key = $data['affiliate_pay']['payment_gateway_data']['type'];
							switch ($temp_key):											
								case 'paypal':
									$payment_class = ($data['affiliate_pay']['payment_gateway_data']['is_active']) ? 'uap-payment-type-active-paypal' : '';
									?>
									<span class="uap-admin-aff-payment-type <?php echo $payment_class;?>">PayPal</span>
	<input type="hidden" value="paypal" name="paywith" />
									<?php
									break;
								case 'bt':
									$payment_class = ($data['affiliate_pay']['payment_gateway_data']['is_active']) ? 'uap-payment-type-active-bt' : '';
									?>
									<span class="uap-admin-aff-payment-type <?php echo $payment_class;?>"><?php _e('Blockchain Transaction', 'uap');?></span>	
<input type="hidden" value="blockchain_transaction" name="paywith" />										
									<?php
									break;
								case 'stripe':
									$payment_class = '';
									if ($data['affiliate_pay']['payment_gateway_data']['is_active'] && !empty($data['affiliate_pay']['payment_gateway_data']['settings']) && !empty($data['affiliate_pay']['payment_gateway_data']['settings']['uap_affiliate_stripe_name'])
										&& !empty($data['affiliate_pay']['payment_gateway_data']['settings']['uap_affiliate_stripe_card_number']) && !empty($data['affiliate_pay']['payment_gateway_data']['settings']['uap_affiliate_stripe_expiration_month']) 
										&& !empty($data['affiliate_pay']['payment_gateway_data']['settings']['uap_affiliate_stripe_expiration_year']) ) //&& !empty($data['affiliate_pay']['payment_gateway_data']['settings']['uap_affiliate_stripe_cvc'])
									{
										$payment_class = 'uap-payment-type-active-stripe';
									}
									?>
									<span class="uap-admin-aff-payment-type <?php echo $payment_class;?>">Stripe</span>
<input type="hidden" value="stripe" name="paywith" />									
									<?php
									break;
								case 'stripe_v2':
									$payment_class = '';
									if ($data['affiliate_pay']['payment_gateway_data']['is_active']){
										$payment_class = 'uap-payment-type-active-stripe_v2';
									}
									?>
									<span class="uap-admin-aff-payment-type <?php echo $payment_class;?>">Stripe V2</span>
  <input type="hidden" value="stripe_v2" name="paywith" />									

									<?php
									break;															
							endswitch;							
						} else {
							echo '-';
						}
					?></td>
					<td><?php 
						echo uap_return_payment_details_for_user_table($data['affiliate_pay']['payment_gateway_data']);	
					?></td>
					<td><?php echo $data['affiliate_pay']['rank'];?></td>	
					<td><?php echo $data['affiliate_pay']['email'];?>
					<input type="hidden" value="<?php echo $data['affiliate_pay']['email'];?>" name="email" /></td>	
					<td style="font-weight:bold"><?php //echo $data['affiliate_pay']['amount'] . $data['currency'];
			$currecny = blockchain();
			echo '<div>'.$data['affiliate_pay']['eth'].$currecny['eth'].'</div>';
			echo '<div>'.$data['affiliate_pay']['pdt'].$currecny['pdt'].'</div>';	
					?>
					
	<input type="hidden" value="<?php echo $data['affiliate_pay']['amount'];?>" name="amount" />
	<input type="hidden" value="<?php echo $data['affiliate_pay']['eth'];?>" name="eth" />
	<input type="hidden" value="<?php echo $data['affiliate_pay']['pdt'];?>" name="pdt" />
	<input type="hidden" value="<?php echo $data['currency'];?>" name="currency" />
	<input type="hidden" value="<?php echo $data['affiliate_pay']['referrals_in'];?>" name="referrals_in" />	
	<input type="hidden" value="<?php echo $data['affiliate_pay']['affiliate_id'];?>" name="affiliate_id" />	
					</td>	
				</tr>	
				
				</tbody>	
				</table>
		<div style="margin-top: 10px;">
	     <input type="hidden" name="do_payout" value="true" />

		 <input type="submit" value="<?php _e('Request Payout', 'uap');?>" name="do_payment" class="button button-primary button-large" id="button_payout" />
		</div>	
		<?php endif;?>
					
	</form>
</div>

