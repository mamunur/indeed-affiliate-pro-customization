<div class="uap-wrapp-the-errors">
	<div class="uap-register-error">
		<strong><?php _e('Admin Info: ', 'uap');?></strong><?php echo $data['content'];?>
	</div>
</div>

