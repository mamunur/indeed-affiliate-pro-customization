<div class="<?php echo $data['err_class'];?>"><?php  
echo __('<p>This is a Trial Version of <strong>Ultimate Affiliate Pro</strong> plugin. Please add your purchase code into Licence section to enable the Full Ultimate Affiliate Pro Version. Check your ', 'uap') . '<a href="' . $data['url'] . '">' . __('licence section', 'uap') .'</a>.</p>';
?></div>
