<div class="uap-wrapper">
<?php

if(isset($_POST['save'])){
update_option('uap_eth_rate', $_POST['uap_eth_rate']);
update_option('uap_pdt_rate', $_POST['uap_pdt_rate']);
update_option('uap_eth_view', $_POST['uap_eth_view']);
update_option('uap_pdt_view', $_POST['uap_pdt_view']);
update_option('min_eth_bal', $_POST['min_eth_bal']);
update_option('min_pdt_bal', $_POST['min_pdt_bal']);
update_option('max_eth_bal', $_POST['max_eth_bal']);
update_option('max_pdt_bal', $_POST['max_pdt_bal']);
}
$uap_eth_rate = get_option('uap_eth_rate');
$uap_pdt_rate = get_option('uap_pdt_rate');
$uap_eth_view = get_option('uap_eth_view');
$uap_pdt_view = get_option('uap_pdt_view');
$min_eth_bal = get_option('min_eth_bal');
$min_pdt_bal = get_option('min_pdt_bal');
$max_eth_bal = get_option('max_eth_bal');
$max_pdt_bal = get_option('max_pdt_bal');
?>
<form action="" method="post">
<div class="uap-stuffbox">
	<h3 class="uap-h3"><?php _e('General Settings', 'uap');?></h3>
	<div class="inside">
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-6">
					<h3><?php _e('Which Amount should be used for Referral?', 'uap');?></h3>
					<p><?php _e('If there are multiple Amounts set for the same action, like Ranks&Offers or multiple Offers decide which one will be taken in consideration', 'uap');?></p>
					<div class="uap-form-line">
							<select name="uap_referral_offer_type" class="form-control m-bot15"><?php
							$types = array('lowest'=>__('Lowest Amount', 'uap'), 'biggest'=>__('Biggest Amount', 'uap'));
							foreach ($types as $key=>$value){
								$selected = ($key==$data['metas']['uap_referral_offer_type']) ? 'selected' : '';
								?>
								<option value="<?php echo $key?>" <?php echo $selected;?>><?php echo $value;?></option>
								<?php
							}
						?></select>
					</div>
				</div>
			</div>
		</div>
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-6">
					<h3><?php _e('Redirect', 'uap');?></h3>
					<p><?php _e('Redirect Same Page Without URL parameters:', 'uap');?></p>
					<label class="uap_label_shiwtch" style="margin:10px 0 10px -10px;">
						<?php $checked = ($data['metas']['uap_redirect_without_param']) ? 'checked' : '';?>
						<input type="checkbox" class="uap-switch" onClick="uap_check_and_h(this, '#uap_redirect_without_param');" <?php echo $checked;?> />
						<div class="switch" style="display:inline-block;"></div>
					</label>
					<input type="hidden" name="uap_redirect_without_param" value="<?php echo $data['metas']['uap_redirect_without_param'];?>" id="uap_redirect_without_param" />
				</div>
			</div>
		</div>
		<div class="uap-line-break"></div>
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-4">
				<h3><?php _e('Refferal Settings', 'uap');?></h3>
				<br/>
				<p><?php _e('Set the referral Variable name', 'uap');?></p>
					<div class="form-group">
						<input type="text" class="form-control" value="<?php echo $data['metas']['uap_referral_variable'];?>" name="uap_referral_variable" />
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-xs-4">
				<h3><?php _e('Base Referral Link', 'uap');?></h3>
				<br/>
					<div class="form-group">
						<?php if (empty($data['metas']['uap_referral_custom_base_link'])) $data['metas']['uap_referral_custom_base_link'] = get_home_url();?>
						<input type="text" class="form-control" onBlur="uap_check_base_referral_link(this.value, '<?php echo get_site_url();?>');" value="<?php echo $data['metas']['uap_referral_custom_base_link'];?>" name="uap_referral_custom_base_link" />
					</div>
					<p id="base_referral_link_alert"><?php _e('Please insert a link from the website on which this plugin is installed.
Do not enter a link from a different website.', 'uap');?></p>
				</div>
			</div>

		</div>
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-4">
				<p class="uap-labels-special"><?php _e('Referral Format:', 'uap');?></p>
				<select name="uap_default_ref_format" class="form-control m-bot15"><?php
				$referral_format = array('id' => 'Referral ID', 'username'=>'UserName');
				foreach ($referral_format as $k=>$v){
					$selected = ($data['metas']['uap_default_ref_format']==$k) ? 'selected' : '';
					?>
					<option value="<?php echo $k;?>" <?php echo $selected;?> ><?php echo $v;?></option>
					<?php
				}
				?></select>

				</div>
			</div>
		</div>
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-4">
				<div class="input-group">
					<span class="input-group-addon" id="basic-addon1"><?php _e('Cookie Expiration:', 'uap');?></span>
					<input type="number" min="1" class="form-control" value="<?php echo $data['metas']['uap_cookie_expire'];?>" name="uap_cookie_expire"/>
					<div class="input-group-addon"> <?php _e("Days", 'uap');?></div>
				</div>

				</div>
			</div>
		</div>
		<div class="uap-line-break"></div>
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-4">
				<h3><?php _e('Campaign Settings', 'uap');?></h3>
				<br/>
				<p><?php _e('Set the Campaign Variable name', 'uap');?></p>
					<div class="form-group">
						<input type="text" class="form-control" value="<?php echo $data['metas']['uap_campaign_variable'];?>" name="uap_campaign_variable"  />
					</div>
				</div>
			</div>
		</div>
		<div class="uap-line-break"></div>
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-4">
					<h3><?php _e('Amount Value Settings', 'uap');?></h3>
					<div class="uap-form-line">
						<span class="uap-labels-special"><?php _e('Currency:', 'uap');?></span>
						<select name="uap_currency" class="form-control m-bot15">><?php
							$currency = uap_get_currencies_list();
							foreach ($currency as $k=>$v){
								$selected = ($k==$data['metas']['uap_currency']) ? 'selected' : '';
								?>
								<option value="<?php echo $k;?>" <?php echo $selected;?> ><?php echo $v;?></option>
								<?php
							}
						?></select>
					</div>
					<div class="uap-form-line">
						<span class="uap-labels-special"><?php _e('Currency position:', 'uap');?></span>
						<select name="uap_currency_position" class="form-control m-bot15">><?php
							$positions = array('left' => __('Left', 'uap'), 'right' => __('Right', 'uap'));
							foreach ($positions as $k=>$v){
								$selected = ($k==$data['metas']['uap_currency_position']) ? 'selected' : '';
								?>
								<option value="<?php echo $k;?>" <?php echo $selected;?> ><?php echo $v;?></option>
								<?php
							}
						?></select>
					</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('Etharium currency view:', 'uap');?></span>
			<div class="form-group">
			<input type="text" class="form-control" value="<?php echo $uap_eth_view;?>" name="uap_eth_view"  />
			</div>
		</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('PDT currency view:', 'uap');?></span>
			<div class="form-group">
			<input type="text" class="form-control" value="<?php echo $uap_pdt_view;?>" name="uap_pdt_view"  />
			</div>
		</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('Etharium conversion ratio:', 'uap');?></span>
			<div class="form-group">
			<input type="text" class="form-control" value="<?php echo $uap_eth_rate;?>" name="uap_eth_rate"  /><span class="input-group-addon"><?php _e('%', 'uap');?></span>
			</div>
		</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('USD to PDT conversion rate:', 'uap');?></span>
			<div class="form-group">
			<span class="input-group-addon"><?php _e('PDT price in USD', 'uap');?></span><input type="text" class="form-control" value="<?php echo $uap_pdt_rate;?>" name="uap_pdt_rate"  /><span class="input-group-addon"><?php _e('$', 'uap');?></span>
			</div>
		</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('Minimum Withdrawal Balance in ETH:', 'uap');?></span>
			<div class="form-group">
			<input type="text" class="form-control" value="<?php echo $min_eth_bal;?>" name="min_eth_bal"  />
			</div>
		</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('Minimum Withdrawal Balance in PDT:', 'uap');?></span>
			<div class="form-group">
			<input type="text" class="form-control" value="<?php echo $min_pdt_bal;?>" name="min_pdt_bal"  />
			</div>
		</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('Maximum Withdrawal Balance in ETH:', 'uap');?></span>
			<div class="form-group">
			<input type="text" class="form-control" value="<?php echo $max_eth_bal;?>" name="max_eth_bal"  />
			</div>
		</div>
		<div class="uap-form-line">
		    <span class="uap-labels-special"><?php _e('Maximum Withdrawal Balance in PDT:', 'uap');?></span>
			<div class="form-group">
			<input type="text" class="form-control" value="<?php echo $max_pdt_bal;?>" name="max_pdt_bal"  />
			</div>
		</div>

					<div class="uap-form-line">
						<span class="uap-labels-special"><?php _e('Exclude Shipping', 'uap');?></span>
						<label class="uap_label_shiwtch" style="margin:10px 0 10px -10px;">
							<?php $checked = ($data['metas']['uap_exclude_shipping']) ? 'checked' : '';?>
							<input type="checkbox" class="uap-switch" onClick="uap_check_and_h(this, '#uap_exclude_shipping');" <?php echo $checked;?> />
							<div class="switch" style="display:inline-block;"></div>
						</label>
						<input type="hidden" name="uap_exclude_shipping" value="<?php echo $data['metas']['uap_exclude_shipping'];?>" id="uap_exclude_shipping" />
					</div>

					<div class="uap-form-line">
						<span class="uap-labels-special"><?php _e('Exclude Tax', 'uap');?></span>
						<label class="uap_label_shiwtch" style="margin:10px 0 10px -10px;">
							<?php $checked = ($data['metas']['uap_exclude_tax']) ? 'checked' : '';?>
							<input type="checkbox" class="uap-switch" onClick="uap_check_and_h(this, '#uap_exclude_tax');" <?php echo $checked;?> />
							<div class="switch" style="display:inline-block;"></div>
						</label>
						<input type="hidden" name="uap_exclude_tax" value="<?php echo $data['metas']['uap_exclude_tax'];?>" id="uap_exclude_tax" />
					</div>

				</div>
			</div>
		</div>

		<div class="uap-line-break"></div>

		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-6">
					<h3><?php _e('Automatically Affiliate', 'uap');?></h3>
					<p><?php _e('All new Users become Affiliates', 'uap');?></p>
					<label class="uap_label_shiwtch" style="margin:10px 0 10px -10px;">
						<?php $checked = ($data['metas']['uap_all_new_users_become_affiliates']) ? 'checked' : '';?>
						<input type="checkbox" class="uap-switch" onClick="uap_check_and_h(this, '#uap_all_new_users_become_affiliates');" <?php echo $checked;?> />
						<div class="switch" style="display:inline-block;"></div>
					</label>
					<input type="hidden" name="uap_all_new_users_become_affiliates" value="<?php echo $data['metas']['uap_all_new_users_become_affiliates'];?>" id="uap_all_new_users_become_affiliates" />
				</div>
			</div>
		</div>

		<div class="uap-line-break"></div>
		<div class="uap-inside-item">
			<div class="row">
				<div class="col-xs-6">
					<h3><?php _e('Empty Referrals', 'uap');?></h3>
					<p><?php _e('Save Empty Referrals', 'uap');?></p>
					<label class="uap_label_shiwtch" style="margin:10px 0 10px -10px;">
						<?php $checked = ($data['metas']['uap_empty_referrals_enable']) ? 'checked' : '';?>
						<input type="checkbox" class="uap-switch" onClick="uap_check_and_h(this, '#uap_empty_referrals_enable');" <?php echo $checked;?> />
						<div class="switch" style="display:inline-block;"></div>
					</label>
					<input type="hidden" name="uap_empty_referrals_enable" value="<?php echo $data['metas']['uap_empty_referrals_enable'];?>" id="uap_empty_referrals_enable" />
				</div>
			</div>
		</div>

		<div class="uap-submit-form">
			<input type="submit" value="<?php _e('Save', 'uap');?>" name="save" class="button button-primary button-large" />
		</div>
	</div>
</div>
</form>
</div>
